﻿using Xamarin.Forms;

namespace CarouselPageNavigation
{
	public partial class MainPage : CarouselPage
	{
		public MainPage ()
		{
			InitializeComponent ();
		}
	}
}

