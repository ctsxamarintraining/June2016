Hierarchical Navigation
=======================

This sample demonstrates how to perform hierarchical navigation through a stack of pages in Xamarin.Forms.

For more information about the sample see [Hierarchical Navigation](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/user-interface/navigation/hierarchical/).

Author
------

Craig Dunn / David Britch
