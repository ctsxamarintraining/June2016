﻿using Xamarin.Forms;

namespace TabbedPageWithNavigationPage
{
	public partial class TodayPage : ContentPage
	{
		public TodayPage ()
		{
			InitializeComponent ();
		}
	}
}

