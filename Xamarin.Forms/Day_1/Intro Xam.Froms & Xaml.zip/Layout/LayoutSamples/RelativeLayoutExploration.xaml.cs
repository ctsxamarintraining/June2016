﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutSamples
{
	public partial class RelativeLayoutExploration : ContentPage
	{
		public RelativeLayoutExploration ()
		{
			InitializeComponent ();
		}
	}
}

