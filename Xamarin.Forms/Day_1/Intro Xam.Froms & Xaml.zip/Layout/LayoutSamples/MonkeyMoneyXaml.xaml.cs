﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutSamples
{
	public partial class MonkeyMoneyXaml : ContentPage
	{
		public MonkeyMoneyXaml ()
		{
			InitializeComponent ();
		}
	}
}

