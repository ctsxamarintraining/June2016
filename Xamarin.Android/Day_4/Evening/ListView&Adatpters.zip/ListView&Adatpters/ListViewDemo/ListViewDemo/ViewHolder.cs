﻿using Android.Widget;

namespace ListViewDemo
{
	public class ViewHolder : Java.Lang.Object
	{
		public ImageView Photo     { get; set; }
		public TextView  Name      { get; set; }
		public TextView  Specialty { get; set; }
	}
}