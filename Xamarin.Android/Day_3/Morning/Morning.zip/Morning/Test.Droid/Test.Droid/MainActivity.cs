﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Content.Res;
using System.IO;
using System;

namespace Test.Droid
{
	[Activity(Label = "Test.Droid", MainLauncher = true, Icon = "@mipmap/icon")]
	public class MainActivity : Activity
	{
		int count = 1;

		protected override void OnCreate(Bundle savedInstanceState)
		{
			base.OnCreate(savedInstanceState);

			// Set our view from the "main" layout resource
			SetContentView(Resource.Layout.Main);

			// Get our button from the layout resource,
			// and attach an event to it
			Button button = FindViewById<Button>(Resource.Id.myButton);

			//button.Click += delegate { button.Text = string.Format("{0} clicks!", count++); };

			var currentCulture = System.Globalization.CultureInfo.CurrentCulture;

			AssetManager assets = this.Assets;
			string content;

			using (StreamReader sr = new StreamReader(assets.Open("AboutAssets.txt")))
			{
				content = sr.ReadToEnd();
			}

			Console.WriteLine(content);
		}
	}

	[Application(LargeHeap=true)]
	public class CustomApplication : Application
	{ 
		
	}
}


