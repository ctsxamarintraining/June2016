﻿using System;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;

namespace StandardControls {

    [Activity(Label = "OptionsMenu")]
    public class OptionsMenuScreen : Activity {
        
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.OptionsMenu);
        }

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            menu.Add("Item 1");
            menu.Add("Item 2");
            menu.Add("Item 3");
            return true;
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
			var t = Toast.MakeText(this, "Options Menu '" + item.TitleFormatted+"' clicked", ToastLength.Short);
			t.SetGravity(GravityFlags.Center, 0, 0);
			t.Show();
           
            return base.OnOptionsItemSelected(item);
        }

        
    }
}