﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Graphics;

namespace StandardControls
{
	[Activity (Label = "LayoutUsingCodeScreen")]			
	public class LayoutUsingCodeScreen : Activity
	{
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);

			LinearLayout parent = new LinearLayout(this);


			parent.LayoutParameters  = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);

			parent.Orientation = Orientation.Horizontal;

			//children of parent linearlayout
			LinearLayout layout2 = new LinearLayout(this);
			layout2.LayoutParameters  = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);

			layout2.Orientation = Orientation.Vertical;


			TextView tvParent = new TextView(this);
			tvParent.LayoutParameters  = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WrapContent,LinearLayout.LayoutParams.WrapContent);
			tvParent.Text = "This is TextView Parent";
			tvParent.SetBackgroundColor (Color.Blue);

			parent.AddView (tvParent);
			//children of layout2 LinearLayout

			TextView tv1 = new TextView(this);
			tv1.LayoutParameters  = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
			tv1.Text = "This is TextView 1";
			TextView tv2 = new TextView(this);
			tv2.LayoutParameters  = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
			tv2.Text = "This is TextView 2";
			TextView tv3 = new TextView(this);
			tv3.LayoutParameters  = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
			tv3.Text = "This is TextView 3";
			TextView tv4 = new TextView(this);
			tv4.LayoutParameters  = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
			tv4.Text = "This is TextView 4";


			layout2.AddView(tv1);
			layout2.AddView(tv2);
			layout2.AddView(tv3);
			layout2.AddView(tv4);

			parent.AddView(layout2);

			SetContentView(parent);
		}
	}
}

