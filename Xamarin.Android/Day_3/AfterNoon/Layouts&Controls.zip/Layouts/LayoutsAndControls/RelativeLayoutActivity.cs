﻿

using Android.App;
using Android.OS;

namespace LayoutsAndControls
{
	[Activity (Label = "RelativeLayoutActivity")]			
	public class RelativeLayoutActivity : Activity
	{
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);
			SetContentView (Resource.Layout.RelativeLayout);

		}
	}
}

