﻿

using Android.App;
using Android.OS;

namespace LayoutsAndControls
{
	[Activity (Label = "GridLayoutActivity")]			
	public class GridLayoutActivity : Activity
	{
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);
			SetContentView (Resource.Layout.GridLayout);

		}
	}
}

