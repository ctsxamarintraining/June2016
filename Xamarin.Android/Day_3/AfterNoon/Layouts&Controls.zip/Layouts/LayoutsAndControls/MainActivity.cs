﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace LayoutsAndControls
{
	[Activity (Label = "Layouts", MainLauncher = true, Icon = "@mipmap/icon")]
	public class MainActivity : ListActivity
	{
		
		string[] items;
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);
			items = new string[] { "Layouts", "Controls"};

			//items = new string[] { "Layouts","Controls","Handle Rotation"};
			ListAdapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1, items);
		}

		protected override void OnListItemClick (ListView l, Android.Views.View v, int position, long id)
		{
			base.OnListItemClick (l, v, position, id);
			switch (position) {
			case 0:
				StartActivity (typeof(LayoutsActivity));
				break;
			case 1:
				StartActivity (typeof(ControlsActivity));
				break;
			//case 2:
			//	StartActivity (typeof(RotaionActivity));
			//	break;
			}
		}
	}
}


