﻿using Android.App;
using Android.OS;

namespace LayoutsAndControls
{
	[Activity (Label = "LinerLayoutHorizontalActivity")]			
	public class LinerLayoutHorizontalActivity : Activity
	{
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);
			SetContentView (Resource.Layout.LinerLayoutHorizontal);

		}
	}
}

