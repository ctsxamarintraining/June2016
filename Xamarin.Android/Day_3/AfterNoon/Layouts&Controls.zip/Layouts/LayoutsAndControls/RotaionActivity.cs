﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace LayoutsAndControls
{
	[Activity (Label = "RotaionActivity")]			
	public class RotaionActivity : Activity
	{
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);

			// Create your application here
			SetContentView(Resource.Layout.Rotation);
		}


		public override bool OnCreateOptionsMenu(IMenu menu)
		{
			menu.Add("Item 1");
			menu.Add("Item 2");
			menu.Add("Item 3");
			return true;
		}

		public override bool OnOptionsItemSelected(IMenuItem item)
		{
			var t = Toast.MakeText(this, "Options Menu '" + item.TitleFormatted+"' clicked", ToastLength.Short);
			t.SetGravity(GravityFlags.Center, 0, 0);
			t.Show();

			return base.OnOptionsItemSelected(item);
		}
	}
}

