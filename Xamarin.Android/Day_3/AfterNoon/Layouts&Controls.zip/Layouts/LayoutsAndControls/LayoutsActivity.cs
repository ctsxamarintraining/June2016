﻿using Android.App;
using Android.OS;
using Android.Widget;
using Android.Views;

namespace LayoutsAndControls
{
	[Activity (Label = "Layouts")]			
	public class LayoutsActivity : ListActivity
	{
		string[] items;
		protected override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);
			items = new string[]{"Linear Layout","Linear Layout Horizontal","Relative Layout","Table Layout","Grid Layout"};
			ListAdapter = new ArrayAdapter<string> (this,Android.Resource.Layout.SimpleListItem1,items);
		}

	

		protected override void OnListItemClick (ListView l, Android.Views.View v, int position, long id)
		{
			base.OnListItemClick (l, v, position, id);
			switch (position) {
			case 0:
				StartActivity(typeof(LinerLayoutActivity));
				break;
			case 1:
				StartActivity(typeof(LinerLayoutHorizontalActivity));
				break;
			case 2:
				StartActivity(typeof(RelativeLayoutActivity));
				break;
			case 3:
				StartActivity(typeof(TableLayoutActivity));
				break;
			case 4:
				StartActivity(typeof(GridLayoutActivity));
				break;

			}
		}
	}
}

