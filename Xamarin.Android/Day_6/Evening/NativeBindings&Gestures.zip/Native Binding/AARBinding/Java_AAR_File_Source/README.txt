This folder contains Java source code and Android Studio project files for the AAR file containing the Java code and Android resources.

This is provided for reference only and is not needed to complete the lab exercises.