
package com.xamarin;

public class Info
{
  public static String getPhoneNumber()
  {
	  return "855.926.2746";
  }
}