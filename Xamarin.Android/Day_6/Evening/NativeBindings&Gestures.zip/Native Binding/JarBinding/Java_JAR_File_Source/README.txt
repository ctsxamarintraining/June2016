This folder contains Java source code and Android Studio project files for the JAR file implementing the Pi calculation.

This is provided for reference only and is not needed to complete the lab exercises.