ContactsProvider Demo
=====================

This example shows how to use the ContactsProvider as well as the device owner's profile in Ice Cream Sandwich.
