using System;
using System.Linq;

using Android.App;
using Android.OS;
using Android.Widget;
using System.Json;
using System.Threading.Tasks;
using AndroidHUD;

namespace RotationDemo
{
		[Activity (Label = "NonConfigInstanceActivity", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation)]
		public class NonConfigInstanceActivity : ListActivity
		{
				TweetListWrapper _savedInstance;

				async protected override void OnCreate (Bundle bundle)
				{
						base.OnCreate (bundle);

						var tweetsWrapper = LastNonConfigurationInstance as TweetListWrapper;
						AndHUD.Shared.Show (this, "Loading...", (int)MaskType.Clear);
			await Task.Run (() => {
				if (tweetsWrapper != null)
					PopulateTweetList (tweetsWrapper.Tweets);
				else
					SearchTwitter ("xamarin");
			});
						AndHUD.Shared.Dismiss (this);


				}



				public void SearchTwitter (string text)
				{
						Console.WriteLine ("call twitter");

						var twitter = new Twitter ();
						ParseResults (twitter.GetTweets ());
				}

				void ParseResults (string jsonData)
				{
						var j = (JsonObject)JsonObject.Parse (jsonData);

						var results = (from result in (JsonArray)j ["statuses"]
								let jResult = result as JsonObject
								select jResult ["text"].ToString ()).ToArray ();

						RunOnUiThread (() => {
								PopulateTweetList (results);
						});
				}

				void PopulateTweetList (string[] results)
				{
						ListAdapter = new ArrayAdapter<string> (this, Resource.Layout.ItemView, results);
						_savedInstance = new TweetListWrapper{Tweets=results};
				}

				class TweetListWrapper : Java.Lang.Object
				{
						public string[] Tweets { get; set; }
				}
		}
}