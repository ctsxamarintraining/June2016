Rotation Demo
=============

This is the sample code for the article Handling Rotation.

It shows various techniques for working with device orientation changes in Mono for Android.