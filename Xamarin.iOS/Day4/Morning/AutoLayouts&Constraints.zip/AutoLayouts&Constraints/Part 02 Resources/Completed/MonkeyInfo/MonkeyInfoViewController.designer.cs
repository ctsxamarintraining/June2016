// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using System;
using Foundation;
using UIKit;
using System.CodeDom.Compiler;

namespace MonkeyInfo
{
	[Register ("MonkeyInfoViewController")]
	partial class MonkeyInfoViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIImageView imgMonkey { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (imgMonkey != null) {
				imgMonkey.Dispose ();
				imgMonkey = null;
			}
		}
	}
}
