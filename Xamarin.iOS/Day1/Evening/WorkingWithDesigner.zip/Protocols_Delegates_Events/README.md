Protocols, Delegates, and Events
================================

This sample demonstrates how to interact with Objective-C protocols
from C#, as well as using the alternative C# events/delegates.
