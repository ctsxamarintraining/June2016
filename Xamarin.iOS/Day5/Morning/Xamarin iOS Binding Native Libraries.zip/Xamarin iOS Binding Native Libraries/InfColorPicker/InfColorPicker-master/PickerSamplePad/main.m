//==============================================================================
//
//  main.m
//  PickerSamplePad
//
//  Created by Troy Gaul on 8/17/10.
//
//  Copyright (c) 2011-2013 InfinitApps LLC: http://infinitapps.com
//	Some rights reserved: http://opensource.org/licenses/MIT
//
//==============================================================================

#import <UIKit/UIKit.h>

//------------------------------------------------------------------------------

int main(int argc, char* argv[])
{
	@autoreleasepool {
		int retVal = UIApplicationMain(argc, argv, nil, nil);
		return retVal;
	}
}

//------------------------------------------------------------------------------
