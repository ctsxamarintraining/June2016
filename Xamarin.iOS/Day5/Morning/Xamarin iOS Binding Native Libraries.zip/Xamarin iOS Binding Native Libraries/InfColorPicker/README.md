Working with Images
===================

This sample demonstrates using application support icons (application icon,
settings icon, Spotlight Search icon, iTunes image, launch image, etc).
