﻿using System;

namespace InfColorPicker {

	public enum InfComponentIndex : uint {
		InfComponentIndexHue = 0,
		InfComponentIndexSaturation = 1,
		InfComponentIndexBrightness = 2
	}
}

