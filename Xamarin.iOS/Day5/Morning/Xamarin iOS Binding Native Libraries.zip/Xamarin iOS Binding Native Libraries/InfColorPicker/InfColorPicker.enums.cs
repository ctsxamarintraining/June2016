namespace InfColorPicker {

	public enum <unamed-C-enum> : uint {
		InfComponentIndexHue = 0,
		InfComponentIndexSaturation = 1,
		InfComponentIndexBrightness = 2
	}
}
