using System;
using Foundation;

namespace FileSystem
{
	[Preserve (AllMembers = true)]
	public class TestXml
	{
		public string Title;
		public string Description;
	}
}

