Create Great Apps Fast
MonoTouch and Mono for Android make it easy for .NET developers to dive right into mobile development.
Share Code Between Platforms
Save time by sharing data structures and non-UI code between iOS and Android.
Use Your Existing .NET Skills
Reuse your .NET skills and write code in your mobile apps using C# and familiar libraries.
Powerful and Modern Framework
Write code using a modern, strongly typed, garbage collected framework.
Easy Access To Native APIs
Access to thousands of native iOS and Android APIs.
Target Multiple Devices
Easily write apps that target iPhone, iPad, iPod Touch and Android devices.
Rich IDE Support
Full support for autocomplete in our rich IDE. Or use Visual Studio for Android development.