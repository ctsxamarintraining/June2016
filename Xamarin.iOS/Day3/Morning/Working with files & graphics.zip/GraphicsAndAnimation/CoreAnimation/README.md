Animation Samples
=================

This sample demonstrates the use of Core Animation in iOS. It accompanies the [Core Animation](/guides/ios/application_fundamentals/graphics_animation_ios/core_animation/) guide.