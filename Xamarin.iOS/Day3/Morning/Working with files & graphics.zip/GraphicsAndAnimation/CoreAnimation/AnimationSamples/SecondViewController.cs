using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace AnimationSamples
{
	partial class SecondViewController : UIViewController
	{
		public SecondViewController (IntPtr handle) : base (handle)
		{
		}
	}
}
