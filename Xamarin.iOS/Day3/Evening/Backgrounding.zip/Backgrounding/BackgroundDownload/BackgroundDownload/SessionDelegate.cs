﻿using System;
using System.IO;
using Foundation;

namespace BackgroundDownload
{
    public class SessionDelegate : NSUrlSessionDownloadDelegate
    {
        ViewController _vc;
        public SessionDelegate(ViewController vc)
        {
            this._vc = vc;
        }

        public override void DidResume(NSUrlSession session, NSUrlSessionDownloadTask downloadTask, long resumeFileOffset, long expectedTotalBytes)
        {
            
        }

        public override void DidWriteData(NSUrlSession session, NSUrlSessionDownloadTask downloadTask, long bytesWritten, long totalBytesWritten, long totalBytesExpectedToWrite)
        {
            float percentage = (float)totalBytesWritten / (float)totalBytesExpectedToWrite;

            Console.Write(" Download Percentage : " + percentage);

            this.InvokeOnMainThread(() => 
            { 
                //Update Progress
                _vc.UpdateProgress(percentage);

            } ) ;
        }

        public override void DidCompleteWithError(NSUrlSession session, NSUrlSessionTask task, NSError error)
        {
            
        }

        public override void DidFinishDownloading(NSUrlSession session, NSUrlSessionDownloadTask downloadTask, NSUrl location)
        {

            // The download location will be a file location.
            var sourceFile = location.Path;

            // Construct a destination file name.
            var destFile = downloadTask.OriginalRequest.Url.AbsoluteString.Substring(downloadTask.OriginalRequest.Url.AbsoluteString.LastIndexOf("/") + 1);

            Console.WriteLine("DidFinishDownloading - Task: {0}, Source file: {1}", downloadTask.TaskIdentifier, sourceFile);

            // Copy over to documents folder. Note that we must use NSFileManager here! File.Copy() will not be able to access the source location.
            NSFileManager fileManager = NSFileManager.DefaultManager;

            // Create the filename
            var documentsFolderPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            NSUrl destinationURL = NSUrl.FromFilename(Path.Combine(documentsFolderPath, destFile));

            // Remove any existing file in our destination
            NSError error;
            fileManager.Remove(Path.Combine(documentsFolderPath, destFile), out error);
            bool success = fileManager.Copy(sourceFile, Path.Combine(documentsFolderPath, destFile), out error);
            if (!success)
            {
                Console.WriteLine("Error during the copy: {0}", error.LocalizedDescription);
            }
        }


        public override void DidFinishEventsForBackgroundSession(NSUrlSession session)
        {
            //if(AppDelegate.CompletionHandler!=null)
            //    AppDelegate.CompletionHandler();

            //AppDelegate.CompletionHandler = null;
        }


    }
}

