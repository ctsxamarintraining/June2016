﻿using System;
using Foundation;
using UIKit;

namespace BackgroundDownload
{
    public partial class ViewController : UIViewController
    {
        private string sessionIdentifier = "com.cognizant.backgroundsession";
        NSUrlSession session;
        string requestURL = "http://xamarinuniversity.blob.core.windows.net/ios210/huge_monkey.png";


        protected ViewController(IntPtr handle) : base(handle)
        {
            // Note: this .ctor should not contain any initialization logic.
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            InitSession();

            StartDownloadBtn.TouchUpInside += OnStartDownloadTouchupInside;

        }

        void OnStartDownloadTouchupInside(object sender, EventArgs e)
        {
            var downloadTask = session.CreateDownloadTask(new NSUrl(requestURL));

            downloadTask.Resume();
        }

        public void InitSession()
        {

            var sessionConfig = UIDevice.CurrentDevice.CheckSystemVersion(8, 0) ?
                                        NSUrlSessionConfiguration.CreateBackgroundSessionConfiguration(sessionIdentifier) 
                                        : NSUrlSessionConfiguration.BackgroundSessionConfiguration(sessionIdentifier);

            sessionConfig.AllowsCellularAccess = true;
            sessionConfig.HttpMaximumConnectionsPerHost = 3;


            SessionDelegate sessionDelegate = new SessionDelegate(this);
            session = NSUrlSession.FromConfiguration(sessionConfig, sessionDelegate, null);
        }


        public void UpdateProgress(float percent)
        {
            ProgressBar.Progress = percent;
        }

    }
}

