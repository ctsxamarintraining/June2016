﻿// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using UIKit;

namespace TouchIDTest
{
    [Register("AuthViewController")]
    partial class AuthViewController
    {
		[Outlet]
		internal UIButton authButton { get; set; }


        void ReleaseDesignerOutlets()
        {
        }
    }
}
