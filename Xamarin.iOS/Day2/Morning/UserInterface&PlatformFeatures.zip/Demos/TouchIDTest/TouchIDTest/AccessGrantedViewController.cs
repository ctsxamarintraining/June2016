﻿using System;
using UIKit;
using Foundation;

namespace TouchIDTest
{
    public partial class AccessGrantedViewController : UIViewController
    {
        public AccessGrantedViewController(IntPtr handle) : base(handle)
        {
        }
    }
}

